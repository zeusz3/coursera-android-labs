/** Automatically generated file. DO NOT MODIFY */
package gr.zcat.dailyselfie;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}